const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, 'public')));
const rooms = new Map();
const words = ['PIZZA','ELEPHANT','BEACH','AIRPLANE','CHOCOLATE','BASKETBALL','RAINBOW','HOSPITAL','GUITAR','WATERFALL','LIBRARY','PENGUIN','MOUNTAIN','POPCORN','BICYCLE','TIGER','SCHOOL','MOON','PILLOW','BURGER'];
const code = () => Math.random().toString(36).slice(2,6).toUpperCase();
function pub(room) { return {code:room.code, phase:room.phase, players:room.players.map(p=>({id:p.id,name:p.name,host:p.id===room.host,ready:p.ready,voteCount:room.phase==='voting'?Object.values(room.votes).filter(v=>v===p.id).length:undefined})), max:8, result:room.result}; }
function emitRoom(room) { io.to(room.code).emit('room', pub(room)); }
function findPlayer(room, id) { return room.players.find(p=>p.id===id); }
function cleanRoom(room) { if (!room.players.length) rooms.delete(room.code); }
io.on('connection', socket => {
  socket.on('create', ({name}, cb) => {
    name=String(name||'').trim().slice(0,18); if(!name) return cb({error:'Enter a nickname'});
    let c; do { c=code(); } while(rooms.has(c));
    const room={code:c,host:socket.id,players:[{id:socket.id,name,ready:true}],phase:'lobby',word:null,imposter:null,votes:{},result:null};
    rooms.set(c,room); socket.join(c); cb({ok:true,code:c}); emitRoom(room);
  });
  socket.on('join', ({code:c,name}, cb) => {
    c=String(c||'').trim().toUpperCase(); name=String(name||'').trim().slice(0,18); const room=rooms.get(c);
    if(!name) return cb({error:'Enter a nickname'}); if(!room) return cb({error:'Room not found'}); if(room.phase!=='lobby') return cb({error:'This game has already started'}); if(room.players.length>=8) return cb({error:'Room is full'});
    if(room.players.some(p=>p.name.toLowerCase()===name.toLowerCase())) return cb({error:'That nickname is already taken'});
    room.players.push({id:socket.id,name,ready:true}); socket.join(c); cb({ok:true,code:c}); emitRoom(room);
  });
  socket.on('start', ({code:c}, cb) => {
    const room=rooms.get(String(c||'').toUpperCase()); if(!room) return cb({error:'Room not found'}); if(room.host!==socket.id) return cb({error:'Only the host can start'}); if(room.players.length<3) return cb({error:'You need at least 3 players'});
    room.word=words[Math.floor(Math.random()*words.length)]; room.imposter=room.players[Math.floor(Math.random()*room.players.length)].id; room.phase='clues'; room.votes={}; room.result=null;
    room.players.forEach(p=>io.to(p.id).emit('role',{imposter:p.id===room.imposter,word:p.id===room.imposter?null:room.word})); emitRoom(room); cb({ok:true});
  });
  socket.on('beginVote', ({code:c}, cb) => { const room=rooms.get(String(c||'').toUpperCase()); if(!room) return cb({error:'Room not found'}); if(room.host!==socket.id) return cb({error:'Only the host can start voting'}); if(room.phase!=='clues') return cb({error:'Not in clue round'}); room.phase='voting'; room.votes={}; emitRoom(room); cb({ok:true}); });
  socket.on('vote', ({code:c,target}, cb) => { const room=rooms.get(String(c||'').toUpperCase()); if(!room||room.phase!=='voting') return cb({error:'Voting is not open'}); if(!findPlayer(room,socket.id)) return cb({error:'You are not in this room'}); if(!findPlayer(room,target)||target===socket.id) return cb({error:'Choose another player'}); room.votes[socket.id]=target; emitRoom(room); if(Object.keys(room.votes).length===room.players.length) { const counts={}; Object.values(room.votes).forEach(id=>counts[id]=(counts[id]||0)+1); const top=Object.entries(counts).sort((a,b)=>b[1]-a[1]); const caught=top.length && top[0][1]>room.players.length/2 && top[0][0]===room.imposter; room.phase='result'; room.result={caught,imposter:findPlayer(room,room.imposter)?.name,word:room.word}; emitRoom(room); io.to(room.code).emit('reveal',room.result); } cb({ok:true}); });
  socket.on('newRound', ({code:c}, cb) => { const room=rooms.get(String(c||'').toUpperCase()); if(!room) return cb({error:'Room not found'}); if(room.host!==socket.id) return cb({error:'Only the host can restart'}); room.phase='lobby'; room.word=null; room.imposter=null; room.votes={}; room.result=null; room.players.forEach(p=>io.to(p.id).emit('role',null)); emitRoom(room); cb({ok:true}); });
  socket.on('disconnect',()=>{ for(const room of rooms.values()){ const i=room.players.findIndex(p=>p.id===socket.id); if(i>=0){ room.players.splice(i,1); if(room.host===socket.id) room.host=room.players[0]?.id; emitRoom(room); cleanRoom(room); } } });
});
const port=process.env.PORT||3000; server.listen(port,()=>console.log(`Imposter app running on ${port}`));
