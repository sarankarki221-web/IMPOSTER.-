# Imposter Party — installable multiplayer web app

This is an Android-friendly Progressive Web App (PWA) with live multiplayer rooms using Socket.IO. It is not an APK yet; users can install it from Chrome after it is deployed over HTTPS.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` on your computer. For friends on other networks, deploy it to a Node.js host with WebSocket support and HTTPS.

## Play
- Create a room, share the four-character code, and have 3–8 players join.
- The host starts the round. Each player privately receives their role and, if not the imposter, the secret word.
- Players discuss and give clues. The host opens voting; each player votes once.
- When everyone has voted, the server reveals the imposter and secret word. The host can start another round.

## Important first-version limitations
- Rooms are held in server memory. Restarting the server clears rooms; use a single server instance for this starter.
- A disconnected player is removed from the room. No reconnect persistence yet.
- No user accounts, chat, moderation, or persistent leaderboard yet.
- This is a party/social game, not a real-money gambling app. It has no deposits, cash prizes, or withdrawals.
- For production, add server-side input validation, rate limiting, moderation/reporting, reconnect support, automated tests, and persistent room/session handling.
